from Live import load_game, welcome
name = input('please enter your name\n')
print(welcome(name))
load_game()
